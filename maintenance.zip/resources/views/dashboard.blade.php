@extends('layouts.bootstrap')
@section('title', 'Tableau de bord')
@section('content')
<h1 class="mb-4">Tableau de bord</h1>
<div class="row g-3 mb-4">
    <div class="col-md-3"><div class="card text-bg-primary"><div class="card-body"><h5>Total</h5><h2>{{ $stats['total'] }}</h2></div></div></div>
    <div class="col-md-3"><div class="card text-bg-warning"><div class="card-body"><h5>Ouverts</h5><h2>{{ $stats['open'] }}</h2></div></div></div>
    <div class="col-md-3"><div class="card text-bg-success"><div class="card-body"><h5>Résolus</h5><h2>{{ $stats['resolved'] }}</h2></div></div></div>
    <div class="col-md-3"><div class="card text-bg-danger"><div class="card-body"><h5>Critiques</h5><h2>{{ $stats['critical'] }}</h2></div></div></div>
</div>
<div class="row g-3 mb-4">
    <div class="col-md-6"><div class="card"><div class="card-body"><h5>Techniciens actifs</h5><h2>{{ $stats['technicians'] }}</h2></div></div></div>
    <div class="col-md-6"><div class="card"><div class="card-body"><h5>Temps moyen de résolution (h)</h5><h2>{{ $avgResolution ? number_format($avgResolution, 2) : 'N/A' }}</h2></div></div></div>
</div>
<h3>Derniers tickets</h3>
<table class="table table-striped">
    <thead><tr><th>ID</th><th>Titre</th><th>Statut</th><th>Priorité</th><th>Demandeur</th><th></th></tr></thead>
    <tbody>
    @foreach($recent as $t)
        <tr>
            <td>{{ $t->id }}</td>
            <td>{{ $t->title }}</td>
            <td><span class="badge bg-secondary">{{ $t->status }}</span></td>
            <td>{{ $t->priority }}</td>
            <td>{{ $t->user?->name }}</td>
            <td><a class="btn btn-sm btn-outline-primary" href="{{ route('tickets.show', $t) }}">Voir</a></td>
        </tr>
    @endforeach
    </tbody>
</table>
@endsection
