<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>Rapport</title></head><body>
<h1>Rapport mensuel des tickets</h1>
<table border="1" cellpadding="5" cellspacing="0" width="100%">
<tr><th>ID</th><th>Titre</th><th>Statut</th><th>Priorité</th><th>Demandeur</th><th>Technicien</th></tr>
@foreach($tickets as $t)
<tr><td>{{ $t->id }}</td><td>{{ $t->title }}</td><td>{{ $t->status }}</td><td>{{ $t->priority }}</td><td>{{ $t->user?->name }}</td><td>{{ $t->assignee?->name }}</td></tr>
@endforeach
</table>
</body></html>
