@extends('layouts.bootstrap')
@section('title', 'Rapports')
@section('content')
<h1>Rapports</h1>
<a href="{{ route('reports.excel') }}" class="btn btn-success">Exporter Excel</a>
<a href="{{ route('reports.pdf') }}" class="btn btn-danger">Exporter PDF</a>
@endsection
