@extends('layouts.bootstrap')
@section('title', 'Ticket #' . $ticket->id)
@section('content')
<div class="d-flex justify-content-between align-items-center mb-3">
    <h1>{{ $ticket->title }}</h1>
    <span class="badge bg-info">{{ $ticket->status }}</span>
</div>
<div class="card mb-3"><div class="card-body">
    <p>{{ $ticket->description }}</p>
    <p><strong>Catégorie:</strong> {{ $ticket->category?->name }}</p>
    <p><strong>Priorité:</strong> {{ $ticket->priority }}</p>
    <p><strong>Demandeur:</strong> {{ $ticket->user?->name }}</p>
    <p><strong>Technicien:</strong> {{ $ticket->assignee?->name ?? 'Non assigné' }}</p>
    <p><strong>Échéance:</strong> {{ $ticket->deadline?->format('d/m/Y H:i') ?? 'N/A' }}</p>
    @if($ticket->attachment)
        <p><a href="{{ asset('storage/' . $ticket->attachment) }}" target="_blank">Pièce jointe</a></p>
    @endif
</div></div>

@can('assign', $ticket)
<div class="card mb-3"><div class="card-body">
    <h5>Affecter un technicien</h5>
    <form method="POST" action="{{ route('tickets.assign', $ticket) }}" class="row g-2">
        @csrf
        <div class="col"><select name="technician_id" class="form-select" required>@foreach($technicians as $t)<option value="{{ $t->id }}">{{ $t->name }}</option>@endforeach</select></div>
        <div class="col"><input type="date" name="deadline" class="form-control"></div>
        <div class="col-auto"><button class="btn btn-primary">Affecter</button></div>
    </form>
</div></div>
@endcan

@can('changeStatus', $ticket)
<div class="card mb-3"><div class="card-body">
    <h5>Changer le statut</h5>
    <form method="POST" action="{{ route('tickets.status', $ticket) }}" class="d-flex gap-2">
        @csrf
        @php
            $next = match($ticket->status) {
                'new' => 'assigned', 'assigned' => 'in_progress', 'in_progress' => 'resolved', 'resolved' => 'closed', default => null
            };
        @endphp
        @if($next)
            <input type="hidden" name="status" value="{{ $next }}">
            <button class="btn btn-success">Passer à {{ $next }}</button>
        @endif
    </form>
</div></div>
@endcan

<div class="row">
    <div class="col-md-8">
        <h4>Commentaires</h4>
        @foreach($ticket->comments as $c)
            <div class="card mb-2"><div class="card-body">
                <strong>{{ $c->user?->name }}</strong> <small class="text-muted">{{ $c->created_at->format('d/m/Y H:i') }}</small>
                <p>{{ $c->message }}</p>
                @if($c->attachment)<a href="{{ asset('storage/' . $c->attachment) }}">Fichier</a>@endif
            </div></div>
        @endforeach
        <form method="POST" action="{{ route('tickets.comments.store', $ticket) }}" enctype="multipart/form-data">
            @csrf
            <div class="mb-2"><textarea name="message" class="form-control" required></textarea></div>
            <div class="mb-2"><input type="file" name="attachment" class="form-control"></div>
            <button class="btn btn-primary">Commenter</button>
        </form>
    </div>
    <div class="col-md-4">
        <h4>Historique</h4>
        <ul class="list-group">
            @foreach($ticket->activities as $a)
                <li class="list-group-item">
                    <strong>{{ $a->action }}</strong><br>
                    <small>{{ $a->description }}</small><br>
                    <small class="text-muted">{{ $a->created_at->format('d/m/Y H:i') }} - {{ $a->user?->name }}</small>
                </li>
            @endforeach
        </ul>
    </div>
</div>
@endsection
