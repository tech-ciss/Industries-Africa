<?php

namespace App\Services;

use App\Models\Ticket;
use App\Models\User;
use App\Services\ActivityService;
use Illuminate\Http\UploadedFile;

class TicketService
{
    public function __construct(private ActivityService $activity) {}

    public function create(array $data, User $user, ?UploadedFile $attachment = null): Ticket
    {
        if ($attachment) {
            $data['attachment'] = $attachment->store('tickets', 'public');
        }
        $data['user_id'] = $user->id;
        $data['status'] = 'new';
        $ticket = Ticket::create($data);
        $this->activity->log($ticket, $user, 'created', 'Ticket créé.');
        return $ticket;
    }

    public function assign(Ticket $ticket, User $technician, User $admin, ?\DateTimeInterface $deadline = null): Ticket
    {
        $ticket->update([
            'assigned_to' => $technician->id,
            'deadline' => $deadline,
            'status' => 'assigned',
        ]);
        $this->activity->log($ticket, $admin, 'assigned', "Assigné à {$technician->name}.");
        return $ticket;
    }

    public function changeStatus(Ticket $ticket, string $status, User $user): Ticket
    {
        $allowed = [
            'new' => 'assigned',
            'assigned' => 'in_progress',
            'in_progress' => 'resolved',
            'resolved' => 'closed',
        ];
        if (! isset($allowed[$ticket->status]) || $allowed[$ticket->status] !== $status) {
            throw new \RuntimeException('Transition de statut non autorisée.');
        }
        $updates = ['status' => $status];
        if ($status === 'resolved') {
            $updates['resolved_at'] = now();
        }
        $ticket->update($updates);
        $this->activity->log($ticket, $user, 'status_changed', "Statut changé en {$status}.");
        return $ticket;
    }
}
