<?php

namespace App\Http\Controllers;

use App\Models\Ticket;
use App\Models\User;

class DashboardController extends Controller
{
    public function index()
    {
        $stats = [
            'total' => Ticket::count(),
            'open' => Ticket::whereIn('status', ['new', 'assigned', 'in_progress'])->count(),
            'resolved' => Ticket::whereIn('status', ['resolved', 'closed'])->count(),
            'critical' => Ticket::where('priority', 'critical')->count(),
            'technicians' => User::where('role', 'technician')->where('status', 'active')->count(),
        ];

        $recent = Ticket::with(['user', 'category', 'assignee'])->latest()->take(10)->get();

        $avgResolution = Ticket::whereNotNull('resolved_at')
            ->get()
            ->avg(fn ($t) => $t->created_at->diffInMinutes($t->resolved_at) / 60);

        return view('dashboard', compact('stats', 'recent', 'avgResolution'));
    }
}
