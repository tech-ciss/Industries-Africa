<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Ticket;
use Illuminate\Http\Request;

class TicketController extends Controller
{
    public function index()
    {
        return Ticket::with(['user', 'category', 'assignee'])->paginate(15);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'title' => 'required|min:5|max:255',
            'description' => 'required|min:20',
            'category_id' => 'required|exists:categories,id',
            'priority' => 'required|in:low,normal,high,critical',
        ]);
        $data['user_id'] = $request->user()->id;
        $data['status'] = 'new';
        return Ticket::create($data);
    }

    public function show(Ticket $ticket)
    {
        return $ticket->load(['user', 'category', 'assignee', 'comments']);
    }

    public function update(Request $request, Ticket $ticket)
    {
        $data = $request->validate([
            'title' => 'sometimes|required|min:5|max:255',
            'description' => 'sometimes|required|min:20',
            'category_id' => 'sometimes|exists:categories,id',
            'priority' => 'sometimes|in:low,normal,high,critical',
            'status' => 'sometimes|in:new,assigned,in_progress,resolved,closed',
        ]);
        $ticket->update($data);
        return $ticket;
    }

    public function destroy(Ticket $ticket)
    {
        $ticket->delete();
        return response()->noContent();
    }
}
