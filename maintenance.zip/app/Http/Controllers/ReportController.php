<?php

namespace App\Http\Controllers;

use App\Exports\TicketsExport;
use App\Models\Ticket;
use Barryvdh\DomPDF\Facade\Pdf;
use Maatwebsite\Excel\Facades\Excel;

class ReportController extends Controller
{
    public function index()
    {
        return view('reports.index');
    }

    public function exportExcel()
    {
        return Excel::download(new TicketsExport, 'tickets.xlsx');
    }

    public function exportPdf()
    {
        $tickets = Ticket::with(['user', 'category', 'assignee'])->latest()->get();
        $pdf = Pdf::loadView('reports.pdf', compact('tickets'));
        return $pdf->download('rapport-mensuel.pdf');
    }
}
