<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreTicketRequest;
use App\Http\Requests\UpdateTicketRequest;
use App\Models\Category;
use App\Models\Ticket;
use App\Models\User;
use App\Notifications\TicketAssignedNotification;
use App\Notifications\TicketCreatedNotification;
use App\Notifications\TicketResolvedNotification;
use App\Services\TicketService;
use Illuminate\Http\Request;

class TicketController extends Controller
{
    public function __construct(private TicketService $tickets) {}

    public function index(Request $request)
    {
        $user = $request->user();
        $query = Ticket::with(['user', 'category', 'assignee']);

        if ($user->isEmployee()) {
            $query->where('user_id', $user->id);
        } elseif ($user->isTechnician()) {
            $query->where('assigned_to', $user->id);
        }

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }
        if ($request->filled('priority')) {
            $query->where('priority', $request->priority);
        }
        if ($request->filled('category_id')) {
            $query->where('category_id', $request->category_id);
        }
        if ($request->filled('technician_id')) {
            $query->where('assigned_to', $request->technician_id);
        }
        if ($request->filled('date_from')) {
            $query->whereDate('created_at', '>=', $request->date_from);
        }
        if ($request->filled('date_to')) {
            $query->whereDate('created_at', '<=', $request->date_to);
        }
        if ($request->filled('search')) {
            $query->where('title', 'like', '%' . $request->search . '%');
        }

        $tickets = $query->latest()->paginate(15)->withQueryString();
        $categories = Category::all();
        $technicians = User::where('role', 'technician')->where('status', 'active')->get();

        return view('tickets.index', compact('tickets', 'categories', 'technicians'));
    }

    public function create()
    {
        $categories = Category::all();
        return view('tickets.create', compact('categories'));
    }

    public function store(StoreTicketRequest $request)
    {
        $ticket = $this->tickets->create(
            $request->only(['title', 'description', 'category_id', 'priority']),
            $request->user(),
            $request->file('attachment')
        );

        // notify admins
        User::where('role', 'admin')->get()->each(fn ($admin) => $admin->notify(new TicketCreatedNotification($ticket)));

        return redirect()->route('tickets.show', $ticket)->with('success', 'Demande créée.');
    }

    public function show(Ticket $ticket)
    {
        $this->authorize('view', $ticket);
        $ticket->load(['user', 'category', 'assignee', 'comments.user', 'activities.user']);
        $technicians = User::where('role', 'technician')->where('status', 'active')->get();
        return view('tickets.show', compact('ticket', 'technicians'));
    }

    public function edit(Ticket $ticket)
    {
        $this->authorize('update', $ticket);
        $categories = Category::all();
        return view('tickets.edit', compact('ticket', 'categories'));
    }

    public function update(UpdateTicketRequest $request, Ticket $ticket)
    {
        $this->authorize('update', $ticket);
        $data = $request->only(['title', 'description', 'category_id', 'priority']);
        if ($request->file('attachment')) {
            $data['attachment'] = $request->file('attachment')->store('tickets', 'public');
        }
        $ticket->update($data);
        return redirect()->route('tickets.show', $ticket)->with('success', 'Demande mise à jour.');
    }

    public function destroy(Ticket $ticket)
    {
        $this->authorize('delete', $ticket);
        $ticket->delete();
        return redirect()->route('tickets.index')->with('success', 'Demande supprimée.');
    }

    public function assign(Request $request, Ticket $ticket)
    {
        $this->authorize('assign', $ticket);
        $data = $request->validate([
            'technician_id' => ['required', 'exists:users,id'],
            'deadline' => ['nullable', 'date'],
        ]);
        $technician = User::findOrFail($data['technician_id']);
        $deadline = isset($data['deadline']) ? \Carbon\Carbon::parse($data['deadline']) : null;
        $this->tickets->assign($ticket, $technician, $request->user(), $deadline);
        $technician->notify(new TicketAssignedNotification($ticket));
        return redirect()->route('tickets.show', $ticket)->with('success', 'Technicien assigné.');
    }

    public function changeStatus(Request $request, Ticket $ticket)
    {
        $this->authorize('changeStatus', $ticket);
        $data = $request->validate([
            'status' => ['required', 'in:new,assigned,in_progress,resolved,closed'],
        ]);
        $old = $ticket->status;
        $this->tickets->changeStatus($ticket, $data['status'], $request->user());
        if ($data['status'] === 'resolved') {
            $ticket->user?->notify(new TicketResolvedNotification($ticket));
        }
        return redirect()->route('tickets.show', $ticket)->with('success', 'Statut mis à jour.');
    }
}
