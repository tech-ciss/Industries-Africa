<?php

namespace App\Exports;

use App\Models\Ticket;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;

class TicketsExport implements FromCollection, WithHeadings
{
    public function collection(): \Illuminate\Support\Collection
    {
        return Ticket::with(['user', 'category', 'assignee'])->get()->map(function ($t) {
            return [
                'ID' => $t->id,
                'Titre' => $t->title,
                'Priorité' => $t->priority,
                'Statut' => $t->status,
                'Catégorie' => $t->category?->name,
                'Demandeur' => $t->user?->name,
                'Technicien' => $t->assignee?->name,
                'Créé le' => $t->created_at?->format('d/m/Y H:i'),
            ];
        });
    }

    public function headings(): array
    {
        return ['ID', 'Titre', 'Priorité', 'Statut', 'Catégorie', 'Demandeur', 'Technicien', 'Créé le'];
    }
}
