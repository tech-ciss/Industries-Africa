The Laravel maintenance request platform is now implemented and verified end-to-end.

## What was built
- **Auth / roles**: Breeze auth, `RoleMiddleware`, role-based access (`admin`, `employee`, `technician`), active/inactive users.
- **Core domain**: migrations/models/relations for `Category`, `Ticket`, `Comment`, `Activity`.
- **Ticket workflow**: `new → assigned → in_progress → resolved → closed`, priorities `low/normal/high/critical`, assignment, deadline, attachments, resolution time.
- **Controllers & validation**: `DashboardController`, `TicketController`, `CategoryController`, `UserController`, `CommentController`, `ReportController`, plus API controller; Form Requests for tickets/categories/users/comments.
- **Authorization**: `TicketPolicy`, `CategoryPolicy`, `UserPolicy`, `AuthorizesRequests` trait in base `Controller`.
- **UI**: Bootstrap 5 Blade views under `layouts/bootstrap.blade.php` for dashboard, tickets, comments, history, users, categories, reports.
- **Dashboard**: KPIs, recent tickets, average resolution time, filters by status/priority/category/technician/dates/search.
- **Notifications**: mail notifications on ticket creation/assignment/resolution (`MAIL_MAILER=log`).
- **Reports / bonus**: Excel export (`TicketsExport`) and PDF monthly report; Sanctum API for tickets.
- **Seed data**: 1 admin, 5 technicians, 10 employees, 5 categories, 50 tickets.

## Verified
- Migrations ran successfully and seeders populated data.
- `php artisan test`: 25 tests passed.
- Manual smoke tests: login, dashboard, tickets list/show/create, users, categories, reports (Excel/PDF), API with Sanctum token all returned successful responses.

## Demo credentials
- Admin: `admin@maintenance.test` / `password`
- Seeded users also use password `password`.

The app can be run with `php artisan serve`.