<?php

namespace Database\Seeders;

use App\Models\Category;
use App\Models\Ticket;
use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    use WithoutModelEvents;

    public function run(): void
    {
        // Admin
        User::factory()->admin()->create([
            'name' => 'Admin Principal',
            'email' => 'admin@maintenance.test',
        ]);

        // Technicians (5)
        $technicians = User::factory()->technician()->count(5)->create();

        // Employees (10)
        $employees = User::factory()->count(10)->create();

        // Categories
        $categoryNames = ['Climatisation', 'Electricité', 'Réseau', 'Plomberie', 'Imprimante'];
        foreach ($categoryNames as $name) {
            Category::create(['name' => $name, 'description' => $name]);
        }
        $categories = Category::all();

        // Tickets (50)
        $priorities = ['low', 'normal', 'high', 'critical'];
        $statuses = ['new', 'assigned', 'in_progress', 'resolved', 'closed'];
        for ($i = 0; $i < 50; $i++) {
            $ticket = Ticket::create([
                'title' => 'Incident #' . ($i + 1) . ' - ' . fake()->sentence(3),
                'description' => fake()->paragraph(3),
                'priority' => fake()->randomElement($priorities),
                'status' => fake()->randomElement($statuses),
                'user_id' => $employees->random()->id,
                'category_id' => $categories->random()->id,
                'assigned_to' => fake()->optional(0.7)->randomElement($technicians->pluck('id')->toArray()),
                'deadline' => fake()->optional()->dateTimeBetween('now', '+2 weeks'),
                'resolved_at' => null,
            ]);
            if (in_array($ticket->status, ['resolved', 'closed'], true)) {
                $ticket->update(['resolved_at' => now()]);
            }
        }
    }
}
