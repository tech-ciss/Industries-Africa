<?php
namespace Database\Factories;
use App\Models\Ticket;
use App\Models\User;
use App\Models\Category;
use Illuminate\Database\Eloquent\Factories\Factory;
class TicketFactory extends Factory
{
    protected $model = Ticket::class;
    public function definition(): array
    {
        return [
            'title' => fake()->sentence(4),
            'description' => fake()->paragraph(3),
            'priority' => fake()->randomElement(['low','normal','high','critical']),
            'status' => fake()->randomElement(['new','assigned','in_progress','resolved','closed']),
            'user_id' => User::factory(),
            'category_id' => Category::factory(),
            'assigned_to' => null,
            'deadline' => fake()->optional()->dateTimeBetween('now', '+2 weeks'),
            'resolved_at' => null,
        ];
    }
}
