<?php $__env->startSection('title', 'Nouveau ticket'); ?>
<?php $__env->startSection('content'); ?>
<h1>Nouveau ticket</h1>
<form method="POST" action="<?php echo e(route('tickets.store')); ?>" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="mb-3"><label class="form-label">Titre</label><input name="title" class="form-control" required minlength="5"></div>
    <div class="mb-3"><label class="form-label">Description</label><textarea name="description" class="form-control" required minlength="20"></textarea></div>
    <div class="mb-3"><label class="form-label">Catégorie</label>
        <select name="category_id" class="form-select" required>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($c->id); ?>"><?php echo e($c->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="mb-3"><label class="form-label">Priorité</label>
        <select name="priority" class="form-select" required>
            <?php $__currentLoopData = ['low','normal','high','critical']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($p); ?>"><?php echo e($p); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="mb-3"><label class="form-label">Pièce jointe</label><input type="file" name="attachment" class="form-control"></div>
    <button class="btn btn-primary">Créer</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.bootstrap', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/midorima/Desktop/Formation/Laravel/exercice/projet_by_IA/resources/views/tickets/create.blade.php ENDPATH**/ ?>