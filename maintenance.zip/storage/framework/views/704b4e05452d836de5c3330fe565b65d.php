<?php $__env->startSection('title', 'Ticket #' . $ticket->id); ?>
<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h1><?php echo e($ticket->title); ?></h1>
    <span class="badge bg-info"><?php echo e($ticket->status); ?></span>
</div>
<div class="card mb-3"><div class="card-body">
    <p><?php echo e($ticket->description); ?></p>
    <p><strong>Catégorie:</strong> <?php echo e($ticket->category?->name); ?></p>
    <p><strong>Priorité:</strong> <?php echo e($ticket->priority); ?></p>
    <p><strong>Demandeur:</strong> <?php echo e($ticket->user?->name); ?></p>
    <p><strong>Technicien:</strong> <?php echo e($ticket->assignee?->name ?? 'Non assigné'); ?></p>
    <p><strong>Échéance:</strong> <?php echo e($ticket->deadline?->format('d/m/Y H:i') ?? 'N/A'); ?></p>
    <?php if($ticket->attachment): ?>
        <p><a href="<?php echo e(asset('storage/' . $ticket->attachment)); ?>" target="_blank">Pièce jointe</a></p>
    <?php endif; ?>
</div></div>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('assign', $ticket)): ?>
<div class="card mb-3"><div class="card-body">
    <h5>Affecter un technicien</h5>
    <form method="POST" action="<?php echo e(route('tickets.assign', $ticket)); ?>" class="row g-2">
        <?php echo csrf_field(); ?>
        <div class="col"><select name="technician_id" class="form-select" required><?php $__currentLoopData = $technicians; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($t->id); ?>"><?php echo e($t->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
        <div class="col"><input type="date" name="deadline" class="form-control"></div>
        <div class="col-auto"><button class="btn btn-primary">Affecter</button></div>
    </form>
</div></div>
<?php endif; ?>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('changeStatus', $ticket)): ?>
<div class="card mb-3"><div class="card-body">
    <h5>Changer le statut</h5>
    <form method="POST" action="<?php echo e(route('tickets.status', $ticket)); ?>" class="d-flex gap-2">
        <?php echo csrf_field(); ?>
        <?php
            $next = match($ticket->status) {
                'new' => 'assigned', 'assigned' => 'in_progress', 'in_progress' => 'resolved', 'resolved' => 'closed', default => null
            };
        ?>
        <?php if($next): ?>
            <input type="hidden" name="status" value="<?php echo e($next); ?>">
            <button class="btn btn-success">Passer à <?php echo e($next); ?></button>
        <?php endif; ?>
    </form>
</div></div>
<?php endif; ?>

<div class="row">
    <div class="col-md-8">
        <h4>Commentaires</h4>
        <?php $__currentLoopData = $ticket->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card mb-2"><div class="card-body">
                <strong><?php echo e($c->user?->name); ?></strong> <small class="text-muted"><?php echo e($c->created_at->format('d/m/Y H:i')); ?></small>
                <p><?php echo e($c->message); ?></p>
                <?php if($c->attachment): ?><a href="<?php echo e(asset('storage/' . $c->attachment)); ?>">Fichier</a><?php endif; ?>
            </div></div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <form method="POST" action="<?php echo e(route('tickets.comments.store', $ticket)); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="mb-2"><textarea name="message" class="form-control" required></textarea></div>
            <div class="mb-2"><input type="file" name="attachment" class="form-control"></div>
            <button class="btn btn-primary">Commenter</button>
        </form>
    </div>
    <div class="col-md-4">
        <h4>Historique</h4>
        <ul class="list-group">
            <?php $__currentLoopData = $ticket->activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-group-item">
                    <strong><?php echo e($a->action); ?></strong><br>
                    <small><?php echo e($a->description); ?></small><br>
                    <small class="text-muted"><?php echo e($a->created_at->format('d/m/Y H:i')); ?> - <?php echo e($a->user?->name); ?></small>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.bootstrap', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/midorima/Desktop/Formation/Laravel/exercice/projet_by_IA/resources/views/tickets/show.blade.php ENDPATH**/ ?>