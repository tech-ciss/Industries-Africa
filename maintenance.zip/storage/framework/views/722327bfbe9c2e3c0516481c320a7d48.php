<?php $__env->startSection('title', 'Tableau de bord'); ?>
<?php $__env->startSection('content'); ?>
<h1 class="mb-4">Tableau de bord</h1>
<div class="row g-3 mb-4">
    <div class="col-md-3"><div class="card text-bg-primary"><div class="card-body"><h5>Total</h5><h2><?php echo e($stats['total']); ?></h2></div></div></div>
    <div class="col-md-3"><div class="card text-bg-warning"><div class="card-body"><h5>Ouverts</h5><h2><?php echo e($stats['open']); ?></h2></div></div></div>
    <div class="col-md-3"><div class="card text-bg-success"><div class="card-body"><h5>Résolus</h5><h2><?php echo e($stats['resolved']); ?></h2></div></div></div>
    <div class="col-md-3"><div class="card text-bg-danger"><div class="card-body"><h5>Critiques</h5><h2><?php echo e($stats['critical']); ?></h2></div></div></div>
</div>
<div class="row g-3 mb-4">
    <div class="col-md-6"><div class="card"><div class="card-body"><h5>Techniciens actifs</h5><h2><?php echo e($stats['technicians']); ?></h2></div></div></div>
    <div class="col-md-6"><div class="card"><div class="card-body"><h5>Temps moyen de résolution (h)</h5><h2><?php echo e($avgResolution ? number_format($avgResolution, 2) : 'N/A'); ?></h2></div></div></div>
</div>
<h3>Derniers tickets</h3>
<table class="table table-striped">
    <thead><tr><th>ID</th><th>Titre</th><th>Statut</th><th>Priorité</th><th>Demandeur</th><th></th></tr></thead>
    <tbody>
    <?php $__currentLoopData = $recent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($t->id); ?></td>
            <td><?php echo e($t->title); ?></td>
            <td><span class="badge bg-secondary"><?php echo e($t->status); ?></span></td>
            <td><?php echo e($t->priority); ?></td>
            <td><?php echo e($t->user?->name); ?></td>
            <td><a class="btn btn-sm btn-outline-primary" href="<?php echo e(route('tickets.show', $t)); ?>">Voir</a></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.bootstrap', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/midorima/Desktop/Formation/Laravel/exercice/projet_by_IA/resources/views/dashboard.blade.php ENDPATH**/ ?>