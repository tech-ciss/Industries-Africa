<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /home/midorima/Desktop/Formation/Laravel/exercice/projet_by_IA/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>