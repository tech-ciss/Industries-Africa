<?php $__env->startSection('title', 'Catégories'); ?>
<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between mb-3"><h1>Catégories</h1><a href="<?php echo e(route('categories.create')); ?>" class="btn btn-primary">Nouvelle</a></div>
<table class="table table-striped"><thead><tr><th>Nom</th><th>Description</th><th>Tickets</th><th></th></tr></thead><tbody>
<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr><td><?php echo e($c->name); ?></td><td><?php echo e($c->description); ?></td><td><?php echo e($c->tickets_count); ?></td>
<td><a href="<?php echo e(route('categories.edit', $c)); ?>" class="btn btn-sm btn-outline-secondary">Modifier</a></td></tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody></table>
<?php echo e($categories->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.bootstrap', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/midorima/Desktop/Formation/Laravel/exercice/projet_by_IA/resources/views/categories/index.blade.php ENDPATH**/ ?>