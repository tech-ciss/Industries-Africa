<?php $__env->startSection('title', 'Utilisateurs'); ?>
<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between mb-3"><h1>Utilisateurs</h1><a href="<?php echo e(route('users.create')); ?>" class="btn btn-primary">Nouveau</a></div>
<table class="table table-striped"><thead><tr><th>Nom</th><th>Email</th><th>Rôle</th><th>Statut</th><th></th></tr></thead><tbody>
<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr><td><?php echo e($u->name); ?></td><td><?php echo e($u->email); ?></td><td><?php echo e($u->role); ?></td><td><?php echo e($u->status); ?></td>
<td><a href="<?php echo e(route('users.edit', $u)); ?>" class="btn btn-sm btn-outline-secondary">Modifier</a></td></tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody></table>
<?php echo e($users->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.bootstrap', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/midorima/Desktop/Formation/Laravel/exercice/projet_by_IA/resources/views/users/index.blade.php ENDPATH**/ ?>