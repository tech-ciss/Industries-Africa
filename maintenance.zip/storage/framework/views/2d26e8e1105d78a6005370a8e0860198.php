<?php $__env->startSection('title', 'Rapports'); ?>
<?php $__env->startSection('content'); ?>
<h1>Rapports</h1>
<a href="<?php echo e(route('reports.excel')); ?>" class="btn btn-success">Exporter Excel</a>
<a href="<?php echo e(route('reports.pdf')); ?>" class="btn btn-danger">Exporter PDF</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.bootstrap', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/midorima/Desktop/Formation/Laravel/exercice/projet_by_IA/resources/views/reports/index.blade.php ENDPATH**/ ?>