<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>Rapport</title></head><body>
<h1>Rapport mensuel des tickets</h1>
<table border="1" cellpadding="5" cellspacing="0" width="100%">
<tr><th>ID</th><th>Titre</th><th>Statut</th><th>Priorité</th><th>Demandeur</th><th>Technicien</th></tr>
<?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr><td><?php echo e($t->id); ?></td><td><?php echo e($t->title); ?></td><td><?php echo e($t->status); ?></td><td><?php echo e($t->priority); ?></td><td><?php echo e($t->user?->name); ?></td><td><?php echo e($t->assignee?->name); ?></td></tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</body></html>
<?php /**PATH /home/midorima/Desktop/Formation/Laravel/exercice/projet_by_IA/resources/views/reports/pdf.blade.php ENDPATH**/ ?>