<?php $__env->startSection('title', 'Nouvelle catégorie'); ?>
<?php $__env->startSection('content'); ?>
<h1>Nouvelle catégorie</h1>
<form method="POST" action="<?php echo e(route('categories.store')); ?>">
<?php echo csrf_field(); ?>
<div class="mb-3"><label>Nom</label><input name="name" class="form-control" required></div>
<div class="mb-3"><label>Description</label><textarea name="description" class="form-control"></textarea></div>
<button class="btn btn-primary">Créer</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.bootstrap', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/midorima/Desktop/Formation/Laravel/exercice/projet_by_IA/resources/views/categories/create.blade.php ENDPATH**/ ?>