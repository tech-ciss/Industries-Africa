<?php $__env->startSection('title', 'Tickets'); ?>
<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between mb-3">
    <h1>Tickets</h1>
    <a href="<?php echo e(route('tickets.create')); ?>" class="btn btn-primary">Nouveau ticket</a>
</div>
<form class="row g-2 mb-3" method="GET">
    <div class="col"><input name="search" value="<?php echo e(request('search')); ?>" class="form-control" placeholder="Recherche"></div>
    <div class="col"><select name="status" class="form-select"><option value="">Statut</option><?php $__currentLoopData = ['new','assigned','in_progress','resolved','closed']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($s); ?>" <?php if(request('status')==$s): echo 'selected'; endif; ?>><?php echo e($s); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
    <div class="col"><select name="priority" class="form-select"><option value="">Priorité</option><?php $__currentLoopData = ['low','normal','high','critical']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($p); ?>" <?php if(request('priority')==$p): echo 'selected'; endif; ?>><?php echo e($p); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
    <div class="col"><select name="category_id" class="form-select"><option value="">Catégorie</option><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($c->id); ?>" <?php if(request('category_id')==$c->id): echo 'selected'; endif; ?>><?php echo e($c->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
    <div class="col"><select name="technician_id" class="form-select"><option value="">Technicien</option><?php $__currentLoopData = $technicians; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($t->id); ?>" <?php if(request('technician_id')==$t->id): echo 'selected'; endif; ?>><?php echo e($t->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
    <div class="col"><input type="date" name="date_from" value="<?php echo e(request('date_from')); ?>" class="form-control"></div>
    <div class="col"><input type="date" name="date_to" value="<?php echo e(request('date_to')); ?>" class="form-control"></div>
    <div class="col-auto"><button class="btn btn-secondary">Filtrer</button></div>
</form>
<table class="table table-striped">
    <thead><tr><th>ID</th><th>Titre</th><th>Statut</th><th>Priorité</th><th>Catégorie</th><th>Demandeur</th><th>Technicien</th><th></th></tr></thead>
    <tbody>
    <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($t->id); ?></td>
            <td><?php echo e($t->title); ?></td>
            <td><?php echo e($t->status); ?></td>
            <td><?php echo e($t->priority); ?></td>
            <td><?php echo e($t->category?->name); ?></td>
            <td><?php echo e($t->user?->name); ?></td>
            <td><?php echo e($t->assignee?->name); ?></td>
            <td><a class="btn btn-sm btn-outline-primary" href="<?php echo e(route('tickets.show', $t)); ?>">Voir</a></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php echo e($tickets->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.bootstrap', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/midorima/Desktop/Formation/Laravel/exercice/projet_by_IA/resources/views/tickets/index.blade.php ENDPATH**/ ?>