<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('title', config('app.name')); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="bg-light">
<nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4">
    <div class="container">
        <a class="navbar-brand" href="<?php echo e(url('/')); ?>"><?php echo e(config('app.name')); ?></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="nav">
            <ul class="navbar-nav me-auto">
                <?php if(auth()->guard()->check()): ?>
                <li class="nav-item"><a class="nav-link" href="<?php echo e(route('dashboard')); ?>">Tableau de bord</a></li>
                <li class="nav-item"><a class="nav-link" href="<?php echo e(route('tickets.index')); ?>">Tickets</a></li>
                <?php if(auth()->user()->isAdmin()): ?>
                <li class="nav-item"><a class="nav-link" href="<?php echo e(route('users.index')); ?>">Utilisateurs</a></li>
                <li class="nav-item"><a class="nav-link" href="<?php echo e(route('categories.index')); ?>">Catégories</a></li>
                <li class="nav-item"><a class="nav-link" href="<?php echo e(route('reports.index')); ?>">Rapports</a></li>
                <?php endif; ?>
                <?php endif; ?>
            </ul>
            <ul class="navbar-nav">
                <?php if(auth()->guard()->check()): ?>
                <li class="nav-item"><span class="nav-link"><?php echo e(auth()->user()->name); ?></span></li>
                <li class="nav-item">
                    <form method="POST" action="<?php echo e(route('logout')); ?>"><?php echo csrf_field(); ?>
                        <button class="btn btn-link nav-link" type="submit">Déconnexion</button>
                    </form>
                </li>
                <?php else: ?>
                <li class="nav-item"><a class="nav-link" href="<?php echo e(route('login')); ?>">Connexion</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
<div class="container">
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger"><ul class="mb-0"><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($e); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul></div>
    <?php endif; ?>
    <?php echo $__env->yieldContent('content'); ?>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH /home/midorima/Desktop/Formation/Laravel/exercice/projet_by_IA/resources/views/layouts/bootstrap.blade.php ENDPATH**/ ?>